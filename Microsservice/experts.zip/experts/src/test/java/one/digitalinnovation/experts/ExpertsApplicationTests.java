package one.digitalinnovation.experts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpertsApplicationTests {

	@Test
	void contextLoads() {
	}

}

package one.digitalinnovantion.experts.productcatalog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductCatalogApplicationTests {

	@Test
	void contextLoads() {
	}

}
